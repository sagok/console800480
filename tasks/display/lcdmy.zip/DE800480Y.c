/**
  ******************************************************************************
  * @file    DE800480Y.c
  * @author  sagok
  * @version V1.0.0
  * @date    09-September-2014
  * @brief   This file includes the LCD driver for DE800480Y LCD.
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
/* Standard includes. */
#include <stdint.h>

#include "DE800480Y.h"

/** @addtogroup BSP
  * @{
  */ 

/** @addtogroup Components
  * @{
  */ 
  
/** @addtogroup DE800480Y
  * @brief     This file provides a set of functions needed to drive the
  *            DE800480Y LCD.
  * @{
  */

/** @defgroup DE800480Y_Private_TypesDefinitions
  * @{
  */

/**
  * @}
  */ 

/** @defgroup DE800480Y_Private_Defines
  * @{
  */

/**
  * @}
  */
  
/** @defgroup DE800480Y_Private_Macros
  * @{
  */

/**
  * @}
  */

/** @defgroup DE800480Y_Private_Variables
  * @{
  */
LCD_DrvTypeDef   de800480y_drv =
{
		de800480y_Init,
		de800480y_ReadID,
		de800480y_DisplayOn,
		de800480y_DisplayOff,
		de800480y_SetCursor,
		de800480y_WritePixel,
		de800480y_ReadPixel,
		de800480y_SetDisplayWindow,
		de800480y_DrawHLine,
		de800480y_DrawVLine,
		de800480y_GetLcdPixelWidth,
		de800480y_GetLcdPixelHeight,
		de800480y_DrawBitmap,
		de800480y_DrawRGBImage,
};

static uint8_t Is_de800480y_Initialized = 0;

/**
  * @}
  */

/** @defgroup de800480y_Private_FunctionPrototypes
  * @{
  */

/**
  * @}
  */
  
/** @defgroup de800480y_Private_Functions
  * @{
  */

/**
  * @brief  Initialise the de800480y LCD Component.
  * @param  None
  * @retval None
  */
void de800480y_Init(void)
{
  if(Is_de800480y_Initialized == 0)
  {
    Is_de800480y_Initialized = 1;
    /* Initialise de800480y low level bus layer --------------------------------*/
    LCD_IO_Init();

    /* Start Initial Sequence ------------------------------------------------*/
    de800480y_WriteReg(LCD_REG_0, 0x0001); /* Start internal OSC. */
    de800480y_WriteReg(LCD_REG_1, 0x0100); /* Set SS and SM bit */
    de800480y_WriteReg(LCD_REG_2, 0x0700); /* Set 1 line inversion */
    de800480y_WriteReg(LCD_REG_3, 0x1018); /* Set GRAM write direction and BGR=1. */
    de800480y_WriteReg(LCD_REG_4, 0x0000); /* Resize register */
    de800480y_WriteReg(LCD_REG_8, 0x0202); /* Set the back porch and front porch */
    de800480y_WriteReg(LCD_REG_9, 0x0000); /* Set non-display area refresh cycle ISC[3:0] */
    de800480y_WriteReg(LCD_REG_10, 0x0000); /* FMARK function */
    de800480y_WriteReg(LCD_REG_12, 0x0000); /* RGB interface setting */
    de800480y_WriteReg(LCD_REG_13, 0x0000); /* Frame marker Position */
    de800480y_WriteReg(LCD_REG_15, 0x0000); /* RGB interface polarity */

    /* Power On sequence -----------------------------------------------------*/
    de800480y_WriteReg(LCD_REG_16, 0x0000); /* SAP, BT[3:0], AP, DSTB, SLP, STB */
    de800480y_WriteReg(LCD_REG_17, 0x0000); /* DC1[2:0], DC0[2:0], VC[2:0] */
    de800480y_WriteReg(LCD_REG_18, 0x0000); /* VREG1OUT voltage */
    de800480y_WriteReg(LCD_REG_19, 0x0000); /* VDV[4:0] for VCOM amplitude */

    de800480y_WriteReg(LCD_REG_16, 0x17B0); /* SAP, BT[3:0], AP, DSTB, SLP, STB */
    de800480y_WriteReg(LCD_REG_17, 0x0137); /* DC1[2:0], DC0[2:0], VC[2:0] */

    de800480y_WriteReg(LCD_REG_18, 0x0139); /* VREG1OUT voltage */

    de800480y_WriteReg(LCD_REG_19, 0x1d00); /* VDV[4:0] for VCOM amplitude */
    de800480y_WriteReg(LCD_REG_41, 0x0013); /* VCM[4:0] for VCOMH */

    de800480y_WriteReg(LCD_REG_32, 0x0000); /* GRAM horizontal Address */
    de800480y_WriteReg(LCD_REG_33, 0x0000); /* GRAM Vertical Address */

    /* Adjust the Gamma Curve (de800480y)---------------------------------------*/
    de800480y_WriteReg(LCD_REG_48, 0x0007);
    de800480y_WriteReg(LCD_REG_49, 0x0302);
    de800480y_WriteReg(LCD_REG_50, 0x0105);
    de800480y_WriteReg(LCD_REG_53, 0x0206);
    de800480y_WriteReg(LCD_REG_54, 0x0808);
    de800480y_WriteReg(LCD_REG_55, 0x0206);
    de800480y_WriteReg(LCD_REG_56, 0x0504);
    de800480y_WriteReg(LCD_REG_57, 0x0007);
    de800480y_WriteReg(LCD_REG_60, 0x0105);
    de800480y_WriteReg(LCD_REG_61, 0x0808);

    /* Set GRAM area ---------------------------------------------------------*/
    de800480y_WriteReg(LCD_REG_80, 0x0000); /* Horizontal GRAM Start Address */
    de800480y_WriteReg(LCD_REG_81, 0x00EF); /* Horizontal GRAM End Address */
    de800480y_WriteReg(LCD_REG_82, 0x0000); /* Vertical GRAM Start Address */
    de800480y_WriteReg(LCD_REG_83, 0x013F); /* Vertical GRAM End Address */

    de800480y_WriteReg(LCD_REG_96,  0xA700); /* Gate Scan Line(GS=1, scan direction is G320~G1) */
    de800480y_WriteReg(LCD_REG_97,  0x0001); /* NDL,VLE, REV */
    de800480y_WriteReg(LCD_REG_106, 0x0000); /* set scrolling line */

    /* Partial Display Control -----------------------------------------------*/
    de800480y_WriteReg(LCD_REG_128, 0x0000);
    de800480y_WriteReg(LCD_REG_129, 0x0000);
    de800480y_WriteReg(LCD_REG_130, 0x0000);
    de800480y_WriteReg(LCD_REG_131, 0x0000);
    de800480y_WriteReg(LCD_REG_132, 0x0000);
    de800480y_WriteReg(LCD_REG_133, 0x0000);

    /* Panel Control ---------------------------------------------------------*/
    de800480y_WriteReg(LCD_REG_144, 0x0010);
    de800480y_WriteReg(LCD_REG_146, 0x0000);
    de800480y_WriteReg(LCD_REG_147, 0x0003);
    de800480y_WriteReg(LCD_REG_149, 0x0110);
    de800480y_WriteReg(LCD_REG_151, 0x0000);
    de800480y_WriteReg(LCD_REG_152, 0x0000);

    /* set GRAM write direction and BGR = 1 */
    /* I/D=00 (Horizontal : increment, Vertical : decrement) */
    /* AM=1 (address is updated in vertical writing direction) */
    de800480y_WriteReg(LCD_REG_3, 0x1018);

    /* 262K color and display ON */
    de800480y_WriteReg(LCD_REG_7, 0x0173);
  }

  /* Set the Cursor */
  de800480y_SetCursor(0, 0);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);
}

/**
  * @brief  Enables the Display.
  * @param  None
  * @retval None
  */
void de800480y_DisplayOn(void)
{
  /* Power On sequence ---------------------------------------------------------*/
  de800480y_WriteReg(LCD_REG_16, 0x0000); /* SAP, BT[3:0], AP, DSTB, SLP, STB */
  de800480y_WriteReg(LCD_REG_17, 0x0000); /* DC1[2:0], DC0[2:0], VC[2:0] */
  de800480y_WriteReg(LCD_REG_18, 0x0000); /* VREG1OUT voltage */
  de800480y_WriteReg(LCD_REG_19, 0x0000); /* VDV[4:0] for VCOM amplitude*/

  de800480y_WriteReg(LCD_REG_16, 0x17B0); /* SAP, BT[3:0], AP, DSTB, SLP, STB */
  de800480y_WriteReg(LCD_REG_17, 0x0137); /* DC1[2:0], DC0[2:0], VC[2:0] */

  de800480y_WriteReg(LCD_REG_18, 0x0139); /* VREG1OUT voltage */

  de800480y_WriteReg(LCD_REG_19, 0x1d00); /* VDV[4:0] for VCOM amplitude */
  de800480y_WriteReg(LCD_REG_41, 0x0013); /* VCM[4:0] for VCOMH */

  /* Display On */
  de800480y_WriteReg(LCD_REG_7, 0x0173); /* 262K color and display ON */
}

/**
  * @brief  Disables the Display.
  * @param  None
  * @retval None
  */
void de800480y_DisplayOff(void)
{
  /* Power Off sequence ---------------------------------------------------------*/
  de800480y_WriteReg(LCD_REG_16, 0x0000); /* SAP, BT[3:0], AP, DSTB, SLP, STB */
  de800480y_WriteReg(LCD_REG_17, 0x0000); /* DC1[2:0], DC0[2:0], VC[2:0] */
  de800480y_WriteReg(LCD_REG_18, 0x0000); /* VREG1OUT voltage */
  de800480y_WriteReg(LCD_REG_19, 0x0000); /* VDV[4:0] for VCOM amplitude*/

  de800480y_WriteReg(LCD_REG_41, 0x0000); /* VCM[4:0] for VCOMH */

  /* Display Off */
  de800480y_WriteReg(LCD_REG_7, 0x0);
}

/**
  * @brief  Get the LCD pixel Width.
  * @param  None
  * @retval The Lcd Pixel Width
  */
uint16_t de800480y_GetLcdPixelWidth(void)
{
 return (uint16_t)320;
}

/**
  * @brief  Get the LCD pixel Height.
  * @param  None
  * @retval The Lcd Pixel Height
  */
uint16_t de800480y_GetLcdPixelHeight(void)
{
 return (uint16_t)240;
}

/**
  * @brief  Get the de800480y ID.
  * @param  None
  * @retval The de800480y ID
  */
uint16_t de800480y_ReadID(void)
{
  if(Is_de800480y_Initialized == 0)
  {
	  de800480y_Init();
  }
  return (de800480y_ReadReg(0x00));
}

/**
  * @brief  Set Cursor position.
  * @param  Xpos: specifies the X position.
  * @param  Ypos: specifies the Y position.
  * @retval None
  */
void de800480y_SetCursor(uint16_t Xpos, uint16_t Ypos)
{
	de800480y_WriteReg(LCD_REG_32, Ypos);
	de800480y_WriteReg(LCD_REG_33, (de800480y_WIDTH - 1 - Xpos));
}

/**
  * @brief  Write pixel.
  * @param  Xpos: specifies the X position.
  * @param  Ypos: specifies the Y position.
  * @param  RGB_Code: the RGB pixel color
  * @retval None
  */
void de800480y_WritePixel(uint16_t Xpos, uint16_t Ypos, uint16_t RGB_Code)
{
  /* Set Cursor */
  de800480y_SetCursor(Xpos, Ypos);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);

  /* Write 16-bit GRAM Reg */
  LCD_IO_WriteData(RGB_Code);
}

/**
  * @brief  Read pixel.
  * @param  None
  * @retval the RGB pixel color
  */
uint16_t de800480y_ReadPixel(uint16_t Xpos, uint16_t Ypos)
{
  /* Set Cursor */
	de800480y_SetCursor(Xpos, Ypos);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);

  /* Dummy read */
  LCD_IO_ReadData();

  /* Read 16-bit Reg */
  return (LCD_IO_ReadData());
}

/**
  * @brief  Writes to the selected LCD register.
  * @param  LCD_Reg:      address of the selected register.
  * @param  LCD_RegValue: value to write to the selected register.
  * @retval None
  */
void de800480y_WriteReg(uint8_t LCD_Reg, uint16_t LCD_RegValue)
{
  LCD_IO_WriteReg(LCD_Reg);

  /* Write 16-bit GRAM Reg */
  LCD_IO_WriteData(LCD_RegValue);
}

/**
  * @brief  Reads the selected LCD Register.
  * @param  LCD_Reg: address of the selected register.
  * @retval LCD Register Value.
  */
uint16_t de800480y_ReadReg(uint8_t LCD_Reg)
{
  /* Write 16-bit Index (then Read Reg) */
  LCD_IO_WriteReg(LCD_Reg);

  /* Read 16-bit Reg */
  return (LCD_IO_ReadData());
}

/**
  * @brief  Sets a display window
  * @param  Xpos:   specifies the X bottom left position.
  * @param  Ypos:   specifies the Y bottom left position.
  * @param  Height: display window height.
  * @param  Width:  display window width.
  * @retval None
  */
void de800480y_SetDisplayWindow(uint16_t Xpos, uint16_t Ypos, uint16_t Width, uint16_t Height)
{
  /* Horizontal GRAM Start Address */
	de800480y_WriteReg(LCD_REG_80, (Ypos));
  /* Horizontal GRAM End Address */
	de800480y_WriteReg(LCD_REG_81, (Ypos + Height - 1));

  /* Vertical GRAM Start Address */
	de800480y_WriteReg(LCD_REG_82, de800480y_WIDTH - Xpos - Width);
  /* Vertical GRAM End Address */
	de800480y_WriteReg(LCD_REG_83, de800480y_WIDTH - Xpos - 1);
}

/**
  * @brief  Draw vertical line.
  * @param  RGB_Code: Specifies the RGB color
  * @param  Xpos:     specifies the X position.
  * @param  Ypos:     specifies the Y position.
  * @param  Length:   specifies the Line length.
  * @retval None
  */
void de800480y_DrawHLine(uint16_t RGB_Code, uint16_t Xpos, uint16_t Ypos, uint16_t Length)
{
  uint16_t i = 0;

  /* Set Cursor */
  de800480y_SetCursor(Xpos, Ypos);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);

  for(i = 0; i < Length; i++)
  {
    /* Write 16-bit GRAM Reg */
    LCD_IO_WriteData(RGB_Code);
  }
}

/**
  * @brief  Draw vertical line.
  * @param  RGB_Code: Specifies the RGB color
  * @param  Xpos:     specifies the X position.
  * @param  Ypos:     specifies the Y position.
  * @param  Length:   specifies the Line length.
  * @retval None
  */
void de800480y_DrawVLine(uint16_t RGB_Code, uint16_t Xpos, uint16_t Ypos, uint16_t Length)
{
  uint16_t i = 0;

  /* set GRAM write direction and BGR = 1 */
  /* I/D=00 (Horizontal : increment, Vertical : decrement) */
  /* AM=1 (address is updated in vertical writing direction) */
  de800480y_WriteReg(LCD_REG_3, 0x1010);

  /* Set Cursor */
  de800480y_SetCursor(Xpos, Ypos);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);

  for(i = 0; i < Length; i++)
  {
    /* Write 16-bit GRAM Reg */
    LCD_IO_WriteData(RGB_Code);
  }

  /* set GRAM write direction and BGR = 1 */
  /* I/D=00 (Horizontal : increment, Vertical : decrement) */
  /* AM=1 (address is updated in vertical writing direction) */
  de800480y_WriteReg(LCD_REG_3, 0x1018);
}

/**
  * @brief  Displays a bitmap picture..
  * @param  BmpAddress: Bmp picture address.
  * @param  Xpos:  Bmp X position in the LCD
  * @param  Ypos:  Bmp Y position in the LCD
  * @retval None
  */
void de800480y_DrawBitmap(uint16_t Xpos, uint16_t Ypos, uint8_t *pbmp)
{
  uint32_t index = 0, size = 0;
  /* Read bitmap size */
  size = *(volatile uint16_t *) (pbmp + 2);
  size |= (*(volatile uint16_t *) (pbmp + 4)) << 16;
  /* Get bitmap data address offset */
  index = *(volatile uint16_t *) (pbmp + 10);
  index |= (*(volatile uint16_t *) (pbmp + 12)) << 16;
  size = (size - index)/2;
  pbmp += index;
  /* Set GRAM write direction and BGR = 1 */
  /* I/D=00 (Horizontal : decrement, Vertical : decrement) */
  /* AM=1 (address is updated in vertical writing direction) */
  de800480y_WriteReg(LCD_REG_3, 0x1008);

  /* Set Cursor */
  de800480y_SetCursor(Xpos, Ypos);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);

  for(index = 0; index < size; index++)
  {
    /* Write 16-bit GRAM Reg */
    LCD_IO_WriteData(*(volatile uint16_t *)pbmp);
    pbmp += 2;
  }

  /* Set GRAM write direction and BGR = 1 */
  /* I/D = 01 (Horizontal : increment, Vertical : decrement) */
  /* AM = 1 (address is updated in vertical writing direction) */
  de800480y_WriteReg(LCD_REG_3, 0x1018);
}

/**
  * @brief  Displays picture..
  * @param  pdata: picture address.
  * @param  Xpos:  Image X position in the LCD
  * @param  Ypos:  Image Y position in the LCD
  * @param  Xsize: Image X size in the LCD
  * @param  Ysize: Image Y size in the LCD
  * @retval None
  */
void de800480y_DrawRGBImage(uint16_t Xpos, uint16_t Ypos, uint16_t Xsize, uint16_t Ysize, uint8_t *pdata)
{
  uint32_t index = 0, size = 0;

  size = (Xsize * Ysize);

  /* Set Cursor */
  de800480y_SetCursor(Xpos, Ypos);

  /* Prepare to write GRAM */
  LCD_IO_WriteReg(LCD_REG_34);

  for(index = 0; index < size; index++)
  {
    /* Write 16-bit GRAM Reg */
    LCD_IO_WriteData(*(volatile uint16_t *)pdata);
    pdata += 2;
  }
}

/**
  * @}
  */ 

/**
  * @}
  */ 

/**
  * @}
  */ 

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
